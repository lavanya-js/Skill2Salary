# 🧠 Skill2Salary - AI Career Intelligence Engine

A premium, futuristic AI-driven web dashboard that visualizes how AI thinks while predicting salary and recommending skills.

## ✨ Features

### Page 1: AI Input Experience
- **Animated AI Brain** - Pulsing neural nodes that respond to user input
- **Step-based Flow** - 4 intuitive steps for career data collection
  - Role selection with suggestions
  - City selection with visual cards
  - Experience slider with growth animation
  - Skills selection with flowing chips
- **Real-time Brain Interaction** - Skills flow into the AI brain as you select them

### Page 2: AI Thinking Mode
- **Full-screen AI Processing Animation**
- **Data Flow Visualization** - Watch your career data being analyzed
- **Progressive Analysis Steps**:
  - Loading Market Data
  - Salary Modeling
  - Skill Gap Analysis
  - Trend Detection
  - Generating Insights
- **Live Progress Tracking** - See each step complete in real-time

### Page 3: Career Intelligence Dashboard

#### 1. Salary Prediction
- AI-predicted salary with min/max range
- 5-year salary projection graph
- Beautiful animated salary visualization
- Market data explanations

#### 2. AI Reasoning Explained
- Visual data flow diagram showing INPUT → ANALYSIS → OUTPUT
- Breakdown of how AI analyzed your profile
- Role, skill, and market context cards

#### 3. Recommended Skills
- Personalized skill recommendations
- "Trending" badges on hot skills
- Hover effects with glow animations
- Based on your role and current skills

#### 4. Industry Trending Skills
- Live radar-style trend analysis
- 9 most booming skills across categories
- Real-time demand percentages
- Category badges (AI/ML, DevOps, Web, etc.)

#### 5. Career Confidence Score
- Circular progress meter with brain icon
- Breakdown of role alignment, skill coverage, and market demand
- Animated percentage counters
- Match percentage explanation

#### 6. Call to Action
- Re-analyze with new skills
- Download AI career report
- Motivational messaging

## 🎨 Design Features

- **Dark + Neon Intelligence Theme**
  - Deep navy/charcoal backgrounds
  - Electric blue (#00d4ff) for AI thinking
  - Neon purple (#b537ff) for recommendations
  - Soft green (#00ff88) for salary growth
  
- **Glassmorphism** - Frosted glass cards with backdrop blur
- **Neon Glows** - Subtle glows on interactive elements
- **Particle Background** - Animated particles connecting across the screen
- **Brain Pulse Animation** - The AI brain breathes and glows
- **Smooth Transitions** - Motion-based page transitions
- **Data Flow Effects** - Animated data flowing between components

## 🛠 Technology Stack

- **React** with TypeScript
- **React Router** (Data mode) for multi-page navigation
- **Motion** (Framer Motion) for animations
- **Recharts** for salary graphs
- **Lucide React** for icons
- **Tailwind CSS v4** for styling
- **Custom CSS** for AI-themed effects

## 🚀 Key Interactions

1. **Input Page**
   - Skills flow into the brain as you select them
   - Brain nodes pulse and activate with interaction
   - Progress bar shows your completion status

2. **Thinking Page**
   - Brain glows brighter during analysis
   - Each analysis step completes with a checkmark
   - Overall progress bar fills up
   - Automatic transition to dashboard

3. **Dashboard**
   - Smooth scroll animations
   - Hover effects on skill cards
   - Interactive charts and graphs
   - Pulsing confidence score meter

## 📊 AI Predictions

The app generates realistic salary predictions based on:
- Selected role (base salary by role)
- Location (city multiplier)
- Years of experience (experience multiplier)
- Number of skills (skill coverage multiplier)

Recommendations are personalized based on the selected role and current skills.

## 🎯 UX Principles

- ✅ Smooth page transitions
- ✅ Animated explanations
- ✅ Visual storytelling
- ✅ No raw numbers without visuals
- ✅ AI feels alive and intelligent
- ✅ Data-driven decision making

---

**Built with ❤️ for Figma Make**
