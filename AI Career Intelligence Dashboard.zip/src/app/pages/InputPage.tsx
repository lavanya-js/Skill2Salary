import { useState } from "react";
import { motion } from "motion/react";
import { useNavigate } from "react-router";
import { AIBrain } from "../components/AIBrain";
import { SkillChip } from "../components/SkillChip";
import { ParticleBackground } from "../components/ParticleBackground";
import { MapPin, Briefcase, Clock, Sparkles } from "lucide-react";

const suggestedRoles = [
  "Software Engineer",
  "Data Scientist",
  "Product Manager",
  "UI/UX Designer",
  "DevOps Engineer",
  "Full Stack Developer"
];

const cities = [
  { name: "Bangalore", icon: "🏙️" },
  { name: "Mumbai", icon: "🌃" },
  { name: "Delhi", icon: "🏛️" },
  { name: "Hyderabad", icon: "🌆" },
  { name: "Pune", icon: "🏢" },
  { name: "Chennai", icon: "🌇" }
];

const popularSkills = [
  "React", "Python", "Machine Learning", "Node.js", 
  "TypeScript", "AWS", "Docker", "Kubernetes",
  "MongoDB", "PostgreSQL", "GraphQL", "Next.js"
];

export function InputPage() {
  const navigate = useNavigate();
  const [step, setStep] = useState(1);
  const [role, setRole] = useState("");
  const [location, setLocation] = useState("");
  const [experience, setExperience] = useState(3);
  const [selectedSkills, setSelectedSkills] = useState<string[]>([]);
  const [customSkill, setCustomSkill] = useState("");

  const handleSkillToggle = (skill: string) => {
    setSelectedSkills(prev =>
      prev.includes(skill)
        ? prev.filter(s => s !== skill)
        : [...prev, skill]
    );
  };

  const addCustomSkill = () => {
    if (customSkill && !selectedSkills.includes(customSkill)) {
      setSelectedSkills(prev => [...prev, customSkill]);
      setCustomSkill("");
    }
  };

  const handleAnalyze = () => {
    // Store data in sessionStorage
    sessionStorage.setItem('careerData', JSON.stringify({
      role,
      location,
      experience,
      skills: selectedSkills
    }));
    navigate('/thinking');
  };

  const canProceed = () => {
    if (step === 1) return role.length > 0;
    if (step === 2) return location.length > 0;
    if (step === 3) return true;
    if (step === 4) return selectedSkills.length > 0;
    return false;
  };

  return (
    <div className="min-h-screen ai-gradient-bg relative overflow-hidden">
      <ParticleBackground />
      
      <div className="relative z-10 grid lg:grid-cols-2 min-h-screen">
        {/* LEFT SIDE - AI Brain */}
        <div className="flex flex-col items-center justify-center p-8 lg:p-16">
          <motion.div
            initial={{ opacity: 0, scale: 0.8 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.8 }}
            className="text-center mb-8"
          >
            <h1 className="text-5xl font-bold bg-gradient-to-r from-[#00d4ff] via-[#b537ff] to-[#00ff88] bg-clip-text text-transparent mb-4">
              Skill2Salary
            </h1>
            <p className="text-white/70 text-lg">AI Career Intelligence Engine</p>
          </motion.div>

          <AIBrain 
            isActive={selectedSkills.length > 0} 
            showNodes={true}
            className="w-full max-w-md"
          />

          <motion.p
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 1 }}
            className="text-white/60 text-center mt-8 text-lg"
          >
            {selectedSkills.length > 0 
              ? "Processing your career profile..."
              : "Understanding your career profile..."
            }
          </motion.p>

          {/* Skill flow visualization */}
          {selectedSkills.length > 0 && (
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              className="mt-6 flex flex-wrap gap-2 justify-center max-w-md"
            >
              {selectedSkills.slice(0, 4).map((skill, index) => (
                <motion.div
                  key={skill}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: index * 0.1 }}
                  className="px-3 py-1 rounded-full bg-[#00d4ff]/20 text-[#00d4ff] text-sm border border-[#00d4ff]/30"
                >
                  {skill}
                </motion.div>
              ))}
              {selectedSkills.length > 4 && (
                <div className="px-3 py-1 rounded-full bg-white/10 text-white/60 text-sm">
                  +{selectedSkills.length - 4} more
                </div>
              )}
            </motion.div>
          )}
        </div>

        {/* RIGHT SIDE - Input Panel */}
        <div className="flex items-center justify-center p-8 lg:p-16">
          <motion.div
            initial={{ opacity: 0, x: 50 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.8 }}
            className="w-full max-w-lg glass-card p-8 lg:p-12 rounded-3xl"
          >
            {/* Progress indicator */}
            <div className="flex gap-2 mb-8">
              {[1, 2, 3, 4].map(s => (
                <div
                  key={s}
                  className={`h-1 flex-1 rounded-full transition-all duration-300 ${
                    s <= step ? 'bg-gradient-to-r from-[#00d4ff] to-[#b537ff]' : 'bg-white/10'
                  }`}
                />
              ))}
            </div>

            {/* Step 1: Role */}
            {step === 1 && (
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                className="space-y-6"
              >
                <div className="flex items-center gap-3 mb-4">
                  <Briefcase className="w-6 h-6 text-[#00d4ff]" />
                  <h2 className="text-2xl font-bold text-white">What role are you aiming for?</h2>
                </div>

                <input
                  type="text"
                  value={role}
                  onChange={(e) => setRole(e.target.value)}
                  placeholder="e.g., Software Engineer"
                  className="w-full px-4 py-3 bg-white/5 border border-white/10 rounded-xl text-white placeholder-white/40 focus:outline-none focus:border-[#00d4ff] transition-colors"
                />

                <div className="space-y-2">
                  <p className="text-white/60 text-sm">Popular roles:</p>
                  <div className="flex flex-wrap gap-2">
                    {suggestedRoles.map(r => (
                      <button
                        key={r}
                        onClick={() => setRole(r)}
                        className="px-3 py-1.5 text-sm bg-white/5 hover:bg-white/10 text-white/80 rounded-lg border border-white/10 hover:border-[#00d4ff]/50 transition-all"
                      >
                        {r}
                      </button>
                    ))}
                  </div>
                </div>
              </motion.div>
            )}

            {/* Step 2: Location */}
            {step === 2 && (
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                className="space-y-6"
              >
                <div className="flex items-center gap-3 mb-4">
                  <MapPin className="w-6 h-6 text-[#b537ff]" />
                  <h2 className="text-2xl font-bold text-white">Where do you want to work?</h2>
                </div>

                <div className="grid grid-cols-2 gap-3">
                  {cities.map(city => (
                    <button
                      key={city.name}
                      onClick={() => setLocation(city.name)}
                      className={`p-4 rounded-xl border-2 transition-all ${
                        location === city.name
                          ? 'border-[#b537ff] bg-[#b537ff]/20 neon-glow-purple'
                          : 'border-white/10 bg-white/5 hover:bg-white/10'
                      }`}
                    >
                      <div className="text-3xl mb-2">{city.icon}</div>
                      <div className="text-white font-medium">{city.name}</div>
                    </button>
                  ))}
                </div>
              </motion.div>
            )}

            {/* Step 3: Experience */}
            {step === 3 && (
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                className="space-y-6"
              >
                <div className="flex items-center gap-3 mb-4">
                  <Clock className="w-6 h-6 text-[#00ff88]" />
                  <h2 className="text-2xl font-bold text-white">Years of experience</h2>
                </div>

                <div className="text-center py-8">
                  <motion.div
                    animate={{ scale: [1, 1.1, 1] }}
                    transition={{ duration: 2, repeat: Infinity }}
                    className="text-7xl font-bold bg-gradient-to-r from-[#00d4ff] to-[#00ff88] bg-clip-text text-transparent mb-6"
                  >
                    {experience}
                  </motion.div>
                  <p className="text-white/60">years</p>
                </div>

                <input
                  type="range"
                  min="0"
                  max="20"
                  value={experience}
                  onChange={(e) => setExperience(parseInt(e.target.value))}
                  className="w-full h-2 bg-white/10 rounded-lg appearance-none cursor-pointer slider"
                  style={{
                    background: `linear-gradient(to right, #00d4ff 0%, #00ff88 ${(experience / 20) * 100}%, rgba(255,255,255,0.1) ${(experience / 20) * 100}%, rgba(255,255,255,0.1) 100%)`
                  }}
                />

                <div className="flex justify-between text-white/40 text-sm">
                  <span>Fresher</span>
                  <span>20+ years</span>
                </div>
              </motion.div>
            )}

            {/* Step 4: Skills */}
            {step === 4 && (
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                className="space-y-6"
              >
                <div className="flex items-center gap-3 mb-4">
                  <Sparkles className="w-6 h-6 text-[#00d4ff]" />
                  <h2 className="text-2xl font-bold text-white">Your current skills</h2>
                </div>

                <div className="flex gap-2">
                  <input
                    type="text"
                    value={customSkill}
                    onChange={(e) => setCustomSkill(e.target.value)}
                    onKeyPress={(e) => e.key === 'Enter' && addCustomSkill()}
                    placeholder="Add a skill..."
                    className="flex-1 px-4 py-3 bg-white/5 border border-white/10 rounded-xl text-white placeholder-white/40 focus:outline-none focus:border-[#00d4ff] transition-colors"
                  />
                  <button
                    onClick={addCustomSkill}
                    className="px-6 py-3 bg-[#00d4ff]/20 text-[#00d4ff] rounded-xl border border-[#00d4ff]/30 hover:bg-[#00d4ff]/30 transition-all"
                  >
                    Add
                  </button>
                </div>

                <div className="space-y-2">
                  <p className="text-white/60 text-sm">Popular skills:</p>
                  <div className="flex flex-wrap gap-2 max-h-64 overflow-y-auto">
                    {popularSkills.map((skill, index) => (
                      <SkillChip
                        key={skill}
                        skill={skill}
                        selected={selectedSkills.includes(skill)}
                        delay={index * 0.05}
                        onClick={() => handleSkillToggle(skill)}
                      />
                    ))}
                  </div>
                </div>

                {selectedSkills.length > 0 && (
                  <div className="space-y-2">
                    <p className="text-white/60 text-sm">Selected ({selectedSkills.length}):</p>
                    <div className="flex flex-wrap gap-2">
                      {selectedSkills.map((skill, index) => (
                        <SkillChip
                          key={skill}
                          skill={skill}
                          selected={true}
                          delay={index * 0.05}
                          onClick={() => handleSkillToggle(skill)}
                        />
                      ))}
                    </div>
                  </div>
                )}
              </motion.div>
            )}

            {/* Navigation Buttons */}
            <div className="flex gap-4 mt-8">
              {step > 1 && (
                <button
                  onClick={() => setStep(step - 1)}
                  className="flex-1 px-6 py-3 bg-white/5 text-white rounded-xl border border-white/10 hover:bg-white/10 transition-all"
                >
                  Back
                </button>
              )}
              
              {step < 4 ? (
                <button
                  onClick={() => setStep(step + 1)}
                  disabled={!canProceed()}
                  className={`flex-1 px-6 py-3 rounded-xl font-semibold transition-all ${
                    canProceed()
                      ? 'bg-gradient-to-r from-[#00d4ff] to-[#b537ff] text-white hover:shadow-lg hover:shadow-[#00d4ff]/50'
                      : 'bg-white/5 text-white/30 cursor-not-allowed'
                  }`}
                >
                  Continue
                </button>
              ) : (
                <button
                  onClick={handleAnalyze}
                  disabled={!canProceed()}
                  className={`flex-1 px-6 py-3 rounded-xl font-semibold transition-all ${
                    canProceed()
                      ? 'bg-gradient-to-r from-[#00d4ff] via-[#b537ff] to-[#00ff88] text-white hover:shadow-lg hover:shadow-[#00d4ff]/50 neon-glow-blue'
                      : 'bg-white/5 text-white/30 cursor-not-allowed'
                  }`}
                >
                  Let AI Analyze My Career ✨
                </button>
              )}
            </div>
          </motion.div>
        </div>
      </div>
    </div>
  );
}
