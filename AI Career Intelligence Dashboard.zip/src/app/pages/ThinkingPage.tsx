import { useEffect, useState } from "react";
import { motion } from "motion/react";
import { useNavigate } from "react-router";
import { AIBrain } from "../components/AIBrain";
import { ParticleBackground } from "../components/ParticleBackground";
import { Check } from "lucide-react";

const analysisSteps = [
  { label: "Loading Market Data", duration: 1000 },
  { label: "Salary Modeling", duration: 1500 },
  { label: "Skill Gap Analysis", duration: 1200 },
  { label: "Trend Detection", duration: 1300 },
  { label: "Generating Insights", duration: 1000 }
];

export function ThinkingPage() {
  const navigate = useNavigate();
  const [currentStep, setCurrentStep] = useState(0);
  const [completedSteps, setCompletedSteps] = useState<number[]>([]);
  const [careerData, setCareerData] = useState<any>(null);

  useEffect(() => {
    // Load career data
    const data = sessionStorage.getItem('careerData');
    if (data) {
      setCareerData(JSON.parse(data));
    }

    // Simulate analysis steps
    let totalTime = 0;
    analysisSteps.forEach((step, index) => {
      setTimeout(() => {
        setCurrentStep(index);
      }, totalTime);

      totalTime += step.duration;

      setTimeout(() => {
        setCompletedSteps(prev => [...prev, index]);
      }, totalTime);
    });

    // Navigate to dashboard after all steps
    setTimeout(() => {
      navigate('/dashboard');
    }, totalTime + 500);

  }, [navigate]);

  return (
    <div className="min-h-screen ai-gradient-bg relative overflow-hidden flex items-center justify-center">
      <ParticleBackground />

      <div className="relative z-10 text-center px-8 max-w-4xl">
        {/* Brain Animation */}
        <motion.div
          initial={{ scale: 0 }}
          animate={{ scale: 1 }}
          transition={{ duration: 0.8, type: "spring" }}
          className="mb-12"
        >
          <AIBrain isActive={true} showNodes={true} className="w-64 h-64 mx-auto" />
        </motion.div>

        {/* Main Message */}
        <motion.h1
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.3 }}
          className="text-4xl font-bold text-white mb-4"
        >
          Analyzing Your Career Profile
        </motion.h1>

        <motion.p
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.5 }}
          className="text-white/60 text-lg mb-12"
        >
          AI is processing market data, salary patterns & industry trends...
        </motion.p>

        {/* Data Flow Visualization */}
        {careerData && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.7 }}
            className="flex flex-wrap justify-center gap-3 mb-12"
          >
            {[
              { label: careerData.role, color: '#00d4ff' },
              { label: careerData.location, color: '#b537ff' },
              { label: `${careerData.experience} years`, color: '#00ff88' },
              { label: `${careerData.skills.length} skills`, color: '#ff0080' }
            ].map((item, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, scale: 0 }}
                animate={{ opacity: 1, scale: 1 }}
                transition={{ delay: 0.9 + index * 0.1 }}
                className="px-4 py-2 rounded-full glass-card text-white"
                style={{ borderColor: item.color, borderWidth: '1px' }}
              >
                <span style={{ color: item.color }}>●</span> {item.label}
              </motion.div>
            ))}
          </motion.div>
        )}

        {/* Analysis Steps */}
        <div className="space-y-4 max-w-md mx-auto">
          {analysisSteps.map((step, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: index * 0.2 }}
              className={`flex items-center gap-4 px-6 py-4 rounded-xl transition-all duration-500 ${
                completedSteps.includes(index)
                  ? 'glass-card border-[#00ff88] border'
                  : currentStep === index
                  ? 'glass-card border-[#00d4ff] border neon-glow-blue'
                  : 'bg-white/5 border border-white/5'
              }`}
            >
              {/* Status Icon */}
              <div className={`w-6 h-6 rounded-full flex items-center justify-center transition-all ${
                completedSteps.includes(index)
                  ? 'bg-[#00ff88]'
                  : currentStep === index
                  ? 'bg-[#00d4ff] pulse-glow'
                  : 'bg-white/10'
              }`}>
                {completedSteps.includes(index) ? (
                  <Check className="w-4 h-4 text-[#0a0e27]" />
                ) : currentStep === index ? (
                  <motion.div
                    animate={{ rotate: 360 }}
                    transition={{ duration: 1, repeat: Infinity, ease: "linear" }}
                    className="w-3 h-3 border-2 border-white border-t-transparent rounded-full"
                  />
                ) : (
                  <div className="w-2 h-2 bg-white/30 rounded-full" />
                )}
              </div>

              {/* Label */}
              <span className={`flex-1 text-left transition-colors ${
                completedSteps.includes(index)
                  ? 'text-[#00ff88]'
                  : currentStep === index
                  ? 'text-white'
                  : 'text-white/40'
              }`}>
                {step.label}
              </span>

              {/* Loading Bar */}
              {currentStep === index && !completedSteps.includes(index) && (
                <div className="flex-1 h-1 bg-white/10 rounded-full overflow-hidden">
                  <motion.div
                    initial={{ width: '0%' }}
                    animate={{ width: '100%' }}
                    transition={{ duration: step.duration / 1000, ease: "linear" }}
                    className="h-full bg-gradient-to-r from-[#00d4ff] to-[#b537ff]"
                  />
                </div>
              )}
            </motion.div>
          ))}
        </div>

        {/* Overall Progress */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 1 }}
          className="mt-12"
        >
          <div className="flex justify-between text-white/60 text-sm mb-2">
            <span>Progress</span>
            <span>{Math.round((completedSteps.length / analysisSteps.length) * 100)}%</span>
          </div>
          <div className="h-2 bg-white/10 rounded-full overflow-hidden">
            <motion.div
              initial={{ width: '0%' }}
              animate={{ width: `${(completedSteps.length / analysisSteps.length) * 100}%` }}
              transition={{ duration: 0.5 }}
              className="h-full bg-gradient-to-r from-[#00d4ff] via-[#b537ff] to-[#00ff88]"
            />
          </div>
        </motion.div>
      </div>
    </div>
  );
}
