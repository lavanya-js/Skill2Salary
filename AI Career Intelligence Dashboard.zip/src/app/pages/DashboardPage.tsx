import { useEffect, useState } from "react";
import { motion } from "motion/react";
import { useNavigate } from "react-router";
import { ParticleBackground } from "../components/ParticleBackground";
import { DataFlowAnimation } from "../components/DataFlowAnimation";
import { SkillChip } from "../components/SkillChip";
import { SalaryGraph } from "../components/SalaryGraph";
import { ConfidenceScore } from "../components/ConfidenceScore";
import { TrendingSkills } from "../components/TrendingSkills";
import { ArrowLeft, Download, RotateCcw, TrendingUp, Brain, Target, Sparkles } from "lucide-react";

// Mock AI predictions based on input
function generatePredictions(data: any) {
  const baseByRole: { [key: string]: number } = {
    "Software Engineer": 1200000,
    "Data Scientist": 1500000,
    "Product Manager": 1800000,
    "UI/UX Designer": 1000000,
    "DevOps Engineer": 1300000,
    "Full Stack Developer": 1250000
  };

  const locationMultiplier: { [key: string]: number } = {
    "Bangalore": 1.0,
    "Mumbai": 0.95,
    "Delhi": 0.9,
    "Hyderabad": 0.85,
    "Pune": 0.88,
    "Chennai": 0.82
  };

  const base = baseByRole[data.role] || 1000000;
  const locMult = locationMultiplier[data.location] || 0.85;
  const expMult = 1 + (data.experience * 0.08);
  const skillMult = 1 + (data.skills.length * 0.03);

  const predicted = Math.round(base * locMult * expMult * skillMult);
  const min = Math.round(predicted * 0.85);
  const max = Math.round(predicted * 1.15);

  return { predicted, min, max };
}

function getRecommendedSkills(role: string, currentSkills: string[]) {
  const roleSkills: { [key: string]: string[] } = {
    "Software Engineer": ["System Design", "Microservices", "Kubernetes", "CI/CD", "Testing"],
    "Data Scientist": ["Deep Learning", "NLP", "TensorFlow", "Spark", "MLOps"],
    "Product Manager": ["Product Analytics", "A/B Testing", "SQL", "Agile", "Roadmapping"],
    "UI/UX Designer": ["Figma", "User Research", "Prototyping", "Design Systems", "Accessibility"],
    "DevOps Engineer": ["Terraform", "Jenkins", "Prometheus", "Grafana", "Helm"],
    "Full Stack Developer": ["System Design", "GraphQL", "Redis", "WebSockets", "Testing"]
  };

  const recommended = roleSkills[role] || ["System Design", "Cloud Computing", "AI/ML", "Leadership"];
  return recommended.filter(skill => !currentSkills.includes(skill));
}

export function DashboardPage() {
  const navigate = useNavigate();
  const [careerData, setCareerData] = useState<any>(null);
  const [predictions, setPredictions] = useState<any>(null);
  const [recommendedSkills, setRecommendedSkills] = useState<string[]>([]);
  const [confidenceScore, setConfidenceScore] = useState(0);

  useEffect(() => {
    const data = sessionStorage.getItem('careerData');
    if (!data) {
      navigate('/');
      return;
    }

    const parsed = JSON.parse(data);
    setCareerData(parsed);

    const pred = generatePredictions(parsed);
    setPredictions(pred);

    const recommended = getRecommendedSkills(parsed.role, parsed.skills);
    setRecommendedSkills(recommended);

    // Calculate confidence score
    const score = Math.min(85 + (parsed.skills.length * 2), 98);
    setTimeout(() => setConfidenceScore(score), 1000);
  }, [navigate]);

  if (!careerData || !predictions) {
    return null;
  }

  return (
    <div className="min-h-screen ai-gradient-bg relative overflow-hidden">
      <ParticleBackground />

      <div className="relative z-10">
        {/* Header */}
        <div className="border-b border-white/10 bg-black/20 backdrop-blur-xl">
          <div className="max-w-7xl mx-auto px-8 py-6 flex items-center justify-between">
            <div className="flex items-center gap-4">
              <motion.button
                onClick={() => navigate('/')}
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
                className="p-2 rounded-xl glass-card hover:bg-white/10 transition-colors"
              >
                <ArrowLeft className="w-5 h-5 text-white" />
              </motion.button>
              <div>
                <h1 className="text-2xl font-bold bg-gradient-to-r from-[#00d4ff] to-[#b537ff] bg-clip-text text-transparent">
                  Career Intelligence Report
                </h1>
                <p className="text-white/60 text-sm">{careerData.role} • {careerData.location}</p>
              </div>
            </div>

            <div className="flex gap-3">
              <motion.button
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
                onClick={() => navigate('/')}
                className="px-4 py-2 glass-card text-white rounded-xl hover:bg-white/10 transition-all flex items-center gap-2"
              >
                <RotateCcw className="w-4 h-4" />
                Re-analyze
              </motion.button>
              <motion.button
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
                className="px-4 py-2 bg-gradient-to-r from-[#00d4ff] to-[#b537ff] text-white rounded-xl flex items-center gap-2 neon-glow-blue"
              >
                <Download className="w-4 h-4" />
                Download Report
              </motion.button>
            </div>
          </div>
        </div>

        {/* Main Content */}
        <div className="max-w-7xl mx-auto px-8 py-12 space-y-12">
          
          {/* Section 1: Salary Prediction */}
          <motion.section
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.2 }}
            className="glass-card p-8 rounded-3xl"
          >
            <div className="flex items-center gap-3 mb-8">
              <TrendingUp className="w-8 h-8 text-[#00ff88]" />
              <div>
                <h2 className="text-3xl font-bold text-white">AI-Predicted Salary</h2>
                <p className="text-white/60">Based on market data & your profile</p>
              </div>
            </div>

            <div className="grid lg:grid-cols-2 gap-8 items-center">
              <div>
                <motion.div
                  initial={{ scale: 0 }}
                  animate={{ scale: 1 }}
                  transition={{ delay: 0.5, type: "spring" }}
                  className="text-center mb-6"
                >
                  <div className="text-6xl font-bold bg-gradient-to-r from-[#00ff88] to-[#00d4ff] bg-clip-text text-transparent mb-2">
                    ₹{(predictions.predicted / 100000).toFixed(1)}L
                  </div>
                  <p className="text-white/60">per annum</p>
                </motion.div>

                <div className="space-y-3">
                  <div className="flex justify-between items-center">
                    <span className="text-white/60">Minimum</span>
                    <span className="text-[#00d4ff] font-semibold">₹{(predictions.min / 100000).toFixed(1)}L</span>
                  </div>
                  <div className="h-2 bg-white/10 rounded-full overflow-hidden">
                    <div 
                      className="h-full bg-gradient-to-r from-[#00d4ff] to-[#00ff88]" 
                      style={{ width: '100%' }}
                    />
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-white/60">Maximum</span>
                    <span className="text-[#00ff88] font-semibold">₹{(predictions.max / 100000).toFixed(1)}L</span>
                  </div>
                </div>

                <div className="mt-6 p-4 bg-white/5 rounded-xl border border-white/10">
                  <p className="text-white/80 text-sm">
                    <span className="text-[#00d4ff]">●</span> Calculated using role, location, experience & skill match
                  </p>
                </div>
              </div>

              <SalaryGraph data={careerData} predictions={predictions} />
            </div>
          </motion.section>

          {/* Section 2: AI Reasoning Explained */}
          <motion.section
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.4 }}
            className="glass-card p-8 rounded-3xl"
          >
            <div className="flex items-center gap-3 mb-8">
              <Brain className="w-8 h-8 text-[#b537ff]" />
              <div>
                <h2 className="text-3xl font-bold text-white">How AI Analyzed Your Profile</h2>
                <p className="text-white/60">Understanding the prediction process</p>
              </div>
            </div>

            <DataFlowAnimation stage="output" />

            <div className="grid md:grid-cols-3 gap-4 mt-8">
              <div className="p-6 bg-white/5 rounded-xl border border-[#00d4ff]/30">
                <Target className="w-6 h-6 text-[#00d4ff] mb-3" />
                <h3 className="text-white font-semibold mb-2">Role Analysis</h3>
                <p className="text-white/60 text-sm">Matched {careerData.role} with market demand patterns</p>
              </div>
              <div className="p-6 bg-white/5 rounded-xl border border-[#b537ff]/30">
                <Brain className="w-6 h-6 text-[#b537ff] mb-3" />
                <h3 className="text-white font-semibold mb-2">Skill Matching</h3>
                <p className="text-white/60 text-sm">Evaluated {careerData.skills.length} skills against industry requirements</p>
              </div>
              <div className="p-6 bg-white/5 rounded-xl border border-[#00ff88]/30">
                <TrendingUp className="w-6 h-6 text-[#00ff88] mb-3" />
                <h3 className="text-white font-semibold mb-2">Market Context</h3>
                <p className="text-white/60 text-sm">Analyzed {careerData.location} market & experience level</p>
              </div>
            </div>
          </motion.section>

          {/* Section 3: Recommended Skills */}
          <motion.section
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.6 }}
            className="glass-card p-8 rounded-3xl"
          >
            <div className="flex items-center gap-3 mb-8">
              <Sparkles className="w-8 h-8 text-[#00d4ff]" />
              <div>
                <h2 className="text-3xl font-bold text-white">Skills You Should Learn Next</h2>
                <p className="text-white/60">Personalized recommendations based on your role & current skills</p>
              </div>
            </div>

            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-4">
              {recommendedSkills.map((skill, index) => (
                <motion.div
                  key={skill}
                  initial={{ opacity: 0, scale: 0.8 }}
                  animate={{ opacity: 1, scale: 1 }}
                  transition={{ delay: 0.8 + index * 0.1 }}
                  whileHover={{ scale: 1.05, y: -5 }}
                  className="p-6 glass-card rounded-xl border border-[#00d4ff]/30 hover:border-[#00d4ff] transition-all cursor-pointer group relative overflow-hidden"
                >
                  <div className="absolute top-2 right-2">
                    <Sparkles className="w-4 h-4 text-[#00ff88] spark" />
                  </div>
                  
                  <h3 className="text-white font-semibold text-lg mb-2">{skill}</h3>
                  <p className="text-white/60 text-sm mb-3">High demand for {careerData.role}</p>
                  
                  <div className="flex items-center gap-2 text-[#00ff88] text-sm">
                    <TrendingUp className="w-4 h-4" />
                    <span>Trending</span>
                  </div>

                  {/* Hover effect */}
                  <div className="absolute inset-0 bg-gradient-to-r from-[#00d4ff]/0 to-[#b537ff]/0 group-hover:from-[#00d4ff]/10 group-hover:to-[#b537ff]/10 transition-all rounded-xl" />
                </motion.div>
              ))}
            </div>
          </motion.section>

          {/* Section 4: Trending Industry Skills */}
          <motion.section
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.8 }}
          >
            <TrendingSkills />
          </motion.section>

          {/* Section 5: Career Confidence Score */}
          <motion.section
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 1 }}
          >
            <ConfidenceScore score={confidenceScore} careerData={careerData} />
          </motion.section>

          {/* Final Section: Call to Action */}
          <motion.section
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 1.2 }}
            className="text-center py-12"
          >
            <motion.div
              animate={{ y: [0, -10, 0] }}
              transition={{ duration: 3, repeat: Infinity }}
              className="inline-block mb-6"
            >
              <div className="w-20 h-20 mx-auto bg-gradient-to-r from-[#00d4ff] to-[#b537ff] rounded-full flex items-center justify-center mb-4">
                <Brain className="w-10 h-10 text-white" />
              </div>
            </motion.div>

            <h2 className="text-4xl font-bold text-white mb-4">
              Your Career Growth is Now Data-Driven
            </h2>
            <p className="text-white/60 text-lg mb-8 max-w-2xl mx-auto">
              Use these AI-powered insights to make informed decisions about your career trajectory
            </p>

            <div className="flex gap-4 justify-center">
              <motion.button
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
                onClick={() => navigate('/')}
                className="px-8 py-4 bg-gradient-to-r from-[#00d4ff] to-[#b537ff] text-white rounded-xl font-semibold neon-glow-blue flex items-center gap-2"
              >
                <RotateCcw className="w-5 h-5" />
                Re-analyze with New Skills
              </motion.button>
              <motion.button
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
                className="px-8 py-4 glass-card text-white rounded-xl font-semibold hover:bg-white/10 transition-all flex items-center gap-2"
              >
                <Download className="w-5 h-5" />
                Download AI Career Report
              </motion.button>
            </div>
          </motion.section>

        </div>
      </div>
    </div>
  );
}
