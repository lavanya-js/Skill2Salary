import { createBrowserRouter } from "react-router";
import { InputPage } from "./pages/InputPage";
import { ThinkingPage } from "./pages/ThinkingPage";
import { DashboardPage } from "./pages/DashboardPage";

export const router = createBrowserRouter([
  {
    path: "/",
    Component: InputPage,
  },
  {
    path: "/thinking",
    Component: ThinkingPage,
  },
  {
    path: "/dashboard",
    Component: DashboardPage,
  },
]);
