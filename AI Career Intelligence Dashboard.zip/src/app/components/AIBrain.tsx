import { motion } from "motion/react";
import { useEffect, useState } from "react";

interface AIBrainProps {
  isActive?: boolean;
  showNodes?: boolean;
  className?: string;
}

export function AIBrain({ isActive = false, showNodes = true, className = "" }: AIBrainProps) {
  const [activeNodes, setActiveNodes] = useState<number[]>([]);

  useEffect(() => {
    if (isActive) {
      const interval = setInterval(() => {
        setActiveNodes(prev => {
          const newNodes = [...prev];
          const randomNode = Math.floor(Math.random() * 12);
          if (newNodes.includes(randomNode)) {
            return newNodes.filter(n => n !== randomNode);
          } else {
            return [...newNodes, randomNode];
          }
        });
      }, 500);

      return () => clearInterval(interval);
    }
  }, [isActive]);

  // Brain node positions (x, y coordinates)
  const nodes = [
    { x: 50, y: 30 },
    { x: 30, y: 50 },
    { x: 70, y: 50 },
    { x: 20, y: 70 },
    { x: 50, y: 60 },
    { x: 80, y: 70 },
    { x: 35, y: 85 },
    { x: 65, y: 85 },
    { x: 45, y: 40 },
    { x: 60, y: 45 },
    { x: 25, y: 60 },
    { x: 75, y: 60 },
  ];

  return (
    <div className={`relative ${className}`}>
      <svg
        viewBox="0 0 200 200"
        className="w-full h-full brain-pulse"
        fill="none"
        xmlns="http://www.w3.org/2000/svg"
      >
        {/* Brain outline */}
        <motion.path
          d="M100 20 C130 20 150 40 150 60 C160 60 170 70 170 85 C170 95 165 105 160 110 C165 120 165 135 160 145 C155 155 145 165 130 170 C120 175 105 180 100 180 C95 180 80 175 70 170 C55 165 45 155 40 145 C35 135 35 120 40 110 C35 105 30 95 30 85 C30 70 40 60 50 60 C50 40 70 20 100 20 Z"
          stroke="url(#brainGradient)"
          strokeWidth="3"
          strokeLinecap="round"
          strokeLinejoin="round"
          initial={{ pathLength: 0 }}
          animate={{ pathLength: 1 }}
          transition={{ duration: 2, ease: "easeInOut" }}
        />

        {/* Neural pathways */}
        <g opacity="0.4">
          <motion.line x1="50" y1="30" x2="30" y2="50" stroke="url(#brainGradient)" strokeWidth="1.5"
            initial={{ pathLength: 0 }}
            animate={{ pathLength: 1 }}
            transition={{ duration: 1.5, delay: 0.5 }}
          />
          <motion.line x1="50" y1="30" x2="70" y2="50" stroke="url(#brainGradient)" strokeWidth="1.5"
            initial={{ pathLength: 0 }}
            animate={{ pathLength: 1 }}
            transition={{ duration: 1.5, delay: 0.6 }}
          />
          <motion.line x1="30" y1="50" x2="20" y2="70" stroke="url(#brainGradient)" strokeWidth="1.5"
            initial={{ pathLength: 0 }}
            animate={{ pathLength: 1 }}
            transition={{ duration: 1.5, delay: 0.7 }}
          />
          <motion.line x1="30" y1="50" x2="50" y2="60" stroke="url(#brainGradient)" strokeWidth="1.5"
            initial={{ pathLength: 0 }}
            animate={{ pathLength: 1 }}
            transition={{ duration: 1.5, delay: 0.8 }}
          />
          <motion.line x1="70" y1="50" x2="50" y2="60" stroke="url(#brainGradient)" strokeWidth="1.5"
            initial={{ pathLength: 0 }}
            animate={{ pathLength: 1 }}
            transition={{ duration: 1.5, delay: 0.9 }}
          />
          <motion.line x1="70" y1="50" x2="80" y2="70" stroke="url(#brainGradient)" strokeWidth="1.5"
            initial={{ pathLength: 0 }}
            animate={{ pathLength: 1 }}
            transition={{ duration: 1.5, delay: 1.0 }}
          />
          <motion.line x1="50" y1="60" x2="35" y2="85" stroke="url(#brainGradient)" strokeWidth="1.5"
            initial={{ pathLength: 0 }}
            animate={{ pathLength: 1 }}
            transition={{ duration: 1.5, delay: 1.1 }}
          />
          <motion.line x1="50" y1="60" x2="65" y2="85" stroke="url(#brainGradient)" strokeWidth="1.5"
            initial={{ pathLength: 0 }}
            animate={{ pathLength: 1 }}
            transition={{ duration: 1.5, delay: 1.2 }}
          />
        </g>

        {/* Nodes */}
        {showNodes && nodes.map((node, index) => (
          <motion.circle
            key={index}
            cx={node.x * 2}
            cy={node.y * 2}
            r={activeNodes.includes(index) ? "8" : "5"}
            fill={activeNodes.includes(index) ? "#00ff88" : "#00d4ff"}
            initial={{ scale: 0 }}
            animate={{ 
              scale: 1,
              opacity: activeNodes.includes(index) ? 1 : 0.6
            }}
            transition={{ 
              duration: 0.3,
              delay: index * 0.1 
            }}
          >
            {activeNodes.includes(index) && (
              <animate
                attributeName="r"
                values="5;10;5"
                dur="1s"
                repeatCount="indefinite"
              />
            )}
          </motion.circle>
        ))}

        {/* Gradient definitions */}
        <defs>
          <linearGradient id="brainGradient" x1="0%" y1="0%" x2="100%" y2="100%">
            <stop offset="0%" stopColor="#00d4ff" />
            <stop offset="50%" stopColor="#b537ff" />
            <stop offset="100%" stopColor="#00ff88" />
          </linearGradient>
        </defs>
      </svg>
    </div>
  );
}
