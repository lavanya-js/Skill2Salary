import { motion } from "motion/react";
import { Sparkles } from "lucide-react";

interface SkillChipProps {
  skill: string;
  isTrending?: boolean;
  delay?: number;
  onClick?: () => void;
  selected?: boolean;
}

export function SkillChip({ 
  skill, 
  isTrending = false, 
  delay = 0, 
  onClick, 
  selected = false 
}: SkillChipProps) {
  return (
    <motion.div
      initial={{ opacity: 0, x: -20 }}
      animate={{ opacity: 1, x: 0 }}
      transition={{ duration: 0.6, delay }}
      whileHover={{ scale: 1.05, y: -2 }}
      whileTap={{ scale: 0.95 }}
      onClick={onClick}
      className={`
        relative inline-flex items-center gap-2 px-4 py-2 rounded-full
        cursor-pointer transition-all duration-300
        ${selected 
          ? 'bg-gradient-to-r from-[#00d4ff] to-[#b537ff] text-white' 
          : 'glass-card text-white/90 hover:bg-white/10'
        }
      `}
    >
      <span className="relative z-10">{skill}</span>
      
      {isTrending && (
        <motion.div
          animate={{ rotate: [0, 10, -10, 0] }}
          transition={{ duration: 2, repeat: Infinity }}
          className="relative z-10"
        >
          <Sparkles className="w-4 h-4 text-[#00ff88]" />
        </motion.div>
      )}

      {isTrending && (
        <span className="absolute -top-1 -right-1 px-2 py-0.5 text-[10px] bg-[#00ff88] text-[#0a0e27] rounded-full font-semibold">
          HOT
        </span>
      )}

      {/* Glow effect */}
      {selected && (
        <div className="absolute inset-0 rounded-full blur-md bg-gradient-to-r from-[#00d4ff] to-[#b537ff] opacity-50 -z-10" />
      )}
    </motion.div>
  );
}
