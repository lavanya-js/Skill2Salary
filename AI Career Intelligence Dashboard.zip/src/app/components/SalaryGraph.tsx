import { motion } from "motion/react";
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Area, AreaChart } from "recharts";

interface SalaryGraphProps {
  data: any;
  predictions: any;
}

export function SalaryGraph({ data, predictions }: SalaryGraphProps) {
  // Generate salary growth data
  const generateGrowthData = () => {
    const years = [];
    const currentYear = 2026;
    const currentExp = data.experience;
    
    for (let i = 0; i <= 5; i++) {
      const yearExp = currentExp + i;
      const growthMultiplier = 1 + (i * 0.12); // 12% annual growth
      const salary = Math.round(predictions.predicted * growthMultiplier);
      
      years.push({
        year: currentYear + i,
        experience: yearExp,
        salary: salary / 100000, // Convert to lakhs
        min: (salary * 0.85) / 100000,
        max: (salary * 1.15) / 100000
      });
    }
    
    return years;
  };

  const growthData = generateGrowthData();

  const CustomTooltip = ({ active, payload }: any) => {
    if (active && payload && payload.length) {
      return (
        <div className="glass-card p-3 rounded-lg border border-white/20">
          <p className="text-white/80 text-sm mb-1">Year {payload[0].payload.year}</p>
          <p className="text-[#00ff88] font-semibold">₹{payload[0].value.toFixed(1)}L</p>
          <p className="text-white/60 text-xs">{payload[0].payload.experience} years exp</p>
        </div>
      );
    }
    return null;
  };

  return (
    <motion.div
      initial={{ opacity: 0, scale: 0.9 }}
      animate={{ opacity: 1, scale: 1 }}
      transition={{ delay: 0.7 }}
      className="p-6 bg-white/5 rounded-2xl border border-white/10"
    >
      <h3 className="text-white font-semibold mb-4">5-Year Salary Projection</h3>
      
      <ResponsiveContainer width="100%" height={250}>
        <AreaChart data={growthData}>
          <defs>
            <linearGradient id="salaryGradient" x1="0" y1="0" x2="0" y2="1">
              <stop offset="5%" stopColor="#00ff88" stopOpacity={0.3}/>
              <stop offset="95%" stopColor="#00ff88" stopOpacity={0}/>
            </linearGradient>
          </defs>
          <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.1)" />
          <XAxis 
            dataKey="year" 
            stroke="rgba(255,255,255,0.5)"
            style={{ fontSize: '12px' }}
          />
          <YAxis 
            stroke="rgba(255,255,255,0.5)"
            style={{ fontSize: '12px' }}
            tickFormatter={(value) => `₹${value}L`}
          />
          <Tooltip content={<CustomTooltip />} />
          <Area
            type="monotone"
            dataKey="salary"
            stroke="#00ff88"
            strokeWidth={3}
            fill="url(#salaryGradient)"
          />
        </AreaChart>
      </ResponsiveContainer>

      <div className="mt-4 p-3 bg-white/5 rounded-lg">
        <p className="text-white/70 text-xs">
          📈 Projected growth: <span className="text-[#00ff88] font-semibold">~12% annually</span> based on industry trends
        </p>
      </div>
    </motion.div>
  );
}
