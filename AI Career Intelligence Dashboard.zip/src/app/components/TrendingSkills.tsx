import { motion } from "motion/react";
import { TrendingUp, Zap, Flame } from "lucide-react";

const trendingSkills = [
  { name: "Generative AI", trend: 95, category: "AI/ML" },
  { name: "Large Language Models", trend: 92, category: "AI/ML" },
  { name: "Kubernetes", trend: 88, category: "DevOps" },
  { name: "React Native", trend: 85, category: "Mobile" },
  { name: "Terraform", trend: 83, category: "Infrastructure" },
  { name: "MLOps", trend: 80, category: "AI/ML" },
  { name: "WebAssembly", trend: 78, category: "Web" },
  { name: "Edge Computing", trend: 76, category: "Cloud" },
  { name: "Blockchain", trend: 74, category: "Web3" },
];

export function TrendingSkills() {
  return (
    <div className="glass-card p-8 rounded-3xl relative overflow-hidden">
      {/* Background wave effect */}
      <div className="absolute top-0 right-0 w-64 h-64 opacity-10">
        <motion.div
          animate={{ 
            scale: [1, 1.2, 1],
            rotate: [0, 90, 0]
          }}
          transition={{ duration: 10, repeat: Infinity }}
          className="w-full h-full bg-gradient-to-r from-[#00d4ff] to-[#b537ff] rounded-full blur-3xl"
        />
      </div>

      <div className="relative z-10">
        <div className="flex items-center gap-3 mb-8">
          <Flame className="w-8 h-8 text-[#ff0080]" />
          <div>
            <h2 className="text-3xl font-bold text-white">What's Booming in the Industry</h2>
            <p className="text-white/60">Live AI trend analysis • Updated Feb 2026</p>
          </div>
        </div>

        {/* Radar visualization effect */}
        <div className="relative mb-8">
          <motion.div
            animate={{ rotate: 360 }}
            transition={{ duration: 20, repeat: Infinity, ease: "linear" }}
            className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-32 h-32"
          >
            <div className="w-full h-full border-2 border-[#00d4ff]/30 rounded-full" />
            <div 
              className="absolute top-0 left-1/2 w-0.5 h-1/2 bg-gradient-to-b from-[#00d4ff] to-transparent"
              style={{ transformOrigin: 'bottom center' }}
            />
          </motion.div>
        </div>

        {/* Skills Grid */}
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-4">
          {trendingSkills.map((skill, index) => (
            <motion.div
              key={skill.name}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: index * 0.1 }}
              whileHover={{ scale: 1.05, y: -5 }}
              className="relative group"
            >
              <div className="p-5 bg-white/5 rounded-xl border border-white/10 hover:border-[#00d4ff]/50 transition-all cursor-pointer overflow-hidden">
                {/* Trend indicator */}
                <div className="flex items-center justify-between mb-3">
                  <span className="text-xs px-2 py-1 bg-white/10 rounded-full text-white/60">
                    {skill.category}
                  </span>
                  <div className="flex items-center gap-1">
                    {skill.trend >= 90 && <Flame className="w-4 h-4 text-[#ff0080] spark" />}
                    {skill.trend >= 80 && <Zap className="w-4 h-4 text-[#00ff88]" />}
                    <TrendingUp className="w-4 h-4 text-[#00d4ff]" />
                  </div>
                </div>

                {/* Skill name */}
                <h3 className="text-white font-semibold mb-3">{skill.name}</h3>

                {/* Trend bar */}
                <div className="space-y-1">
                  <div className="flex justify-between text-xs">
                    <span className="text-white/60">Demand</span>
                    <span className="text-[#00ff88] font-semibold">{skill.trend}%</span>
                  </div>
                  <div className="h-1.5 bg-white/10 rounded-full overflow-hidden">
                    <motion.div
                      initial={{ width: 0 }}
                      animate={{ width: `${skill.trend}%` }}
                      transition={{ delay: 0.5 + index * 0.1, duration: 1 }}
                      className="h-full bg-gradient-to-r from-[#00d4ff] to-[#00ff88] relative"
                    >
                      <div className="absolute inset-0 shimmer" />
                    </motion.div>
                  </div>
                </div>

                {/* Wave animation on hover */}
                <motion.div
                  className="absolute inset-0 bg-gradient-to-r from-[#00d4ff]/0 via-[#00d4ff]/10 to-[#00d4ff]/0"
                  initial={{ x: '-100%' }}
                  whileHover={{ x: '100%' }}
                  transition={{ duration: 0.6 }}
                />
              </div>

              {/* Glow effect */}
              {skill.trend >= 90 && (
                <div className="absolute inset-0 rounded-xl blur-md bg-gradient-to-r from-[#ff0080]/20 to-[#00d4ff]/20 -z-10 opacity-0 group-hover:opacity-100 transition-opacity" />
              )}
            </motion.div>
          ))}
        </div>

        {/* Live indicator */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 1 }}
          className="mt-6 flex items-center justify-center gap-2 text-white/60 text-sm"
        >
          <motion.div
            animate={{ scale: [1, 1.2, 1], opacity: [0.5, 1, 0.5] }}
            transition={{ duration: 2, repeat: Infinity }}
            className="w-2 h-2 bg-[#00ff88] rounded-full"
          />
          <span>Live data from industry reports & job market trends</span>
        </motion.div>
      </div>
    </div>
  );
}
