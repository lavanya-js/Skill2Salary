import { motion } from "motion/react";
import { Brain, DollarSign, Target, MapPin, TrendingUp } from "lucide-react";

interface DataFlowAnimationProps {
  stage: 'input' | 'analysis' | 'output';
}

export function DataFlowAnimation({ stage }: DataFlowAnimationProps) {
  return (
    <div className="flex items-center justify-center gap-8 py-12">
      {/* INPUT */}
      <motion.div
        initial={{ scale: 0 }}
        animate={{ scale: 1 }}
        transition={{ duration: 0.5 }}
        className="relative"
      >
        <div className="glass-card p-6 rounded-2xl">
          <div className="flex flex-col items-center gap-3">
            <Target className="w-8 h-8 text-[#00d4ff]" />
            <span className="text-white/80 text-sm">Role</span>
          </div>
        </div>
        {stage !== 'input' && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            className="absolute -top-1 -right-1 w-3 h-3 bg-[#00ff88] rounded-full"
          >
            <div className="absolute inset-0 bg-[#00ff88] rounded-full animate-ping" />
          </motion.div>
        )}
      </motion.div>

      {/* Arrow 1 */}
      <motion.div
        initial={{ width: 0 }}
        animate={{ width: '60px' }}
        transition={{ duration: 0.5, delay: 0.3 }}
        className="h-0.5 bg-gradient-to-r from-[#00d4ff] to-[#b537ff] relative overflow-hidden"
      >
        {stage !== 'input' && (
          <motion.div
            initial={{ x: '-100%' }}
            animate={{ x: '200%' }}
            transition={{ duration: 1.5, repeat: Infinity }}
            className="absolute inset-0 w-1/3 bg-white/50"
          />
        )}
      </motion.div>

      {/* ANALYSIS - Brain */}
      <motion.div
        initial={{ scale: 0 }}
        animate={{ scale: 1 }}
        transition={{ duration: 0.5, delay: 0.5 }}
        className="relative"
      >
        <div className={`glass-card p-6 rounded-2xl ${stage === 'analysis' ? 'neon-glow-purple' : ''}`}>
          <div className="flex flex-col items-center gap-3">
            <Brain className={`w-10 h-10 text-[#b537ff] ${stage === 'analysis' ? 'pulse-glow' : ''}`} />
            <span className="text-white/80 text-sm">AI Analysis</span>
          </div>
        </div>
        {stage === 'analysis' && (
          <>
            <motion.div
              animate={{ scale: [1, 1.5, 1] }}
              transition={{ duration: 2, repeat: Infinity }}
              className="absolute inset-0 rounded-2xl border-2 border-[#b537ff]/30"
            />
            <motion.div
              animate={{ scale: [1, 1.8, 1] }}
              transition={{ duration: 2, repeat: Infinity, delay: 0.5 }}
              className="absolute inset-0 rounded-2xl border-2 border-[#b537ff]/20"
            />
          </>
        )}
      </motion.div>

      {/* Arrow 2 */}
      <motion.div
        initial={{ width: 0 }}
        animate={{ width: '60px' }}
        transition={{ duration: 0.5, delay: 0.8 }}
        className="h-0.5 bg-gradient-to-r from-[#b537ff] to-[#00ff88] relative overflow-hidden"
      >
        {stage === 'output' && (
          <motion.div
            initial={{ x: '-100%' }}
            animate={{ x: '200%' }}
            transition={{ duration: 1.5, repeat: Infinity }}
            className="absolute inset-0 w-1/3 bg-white/50"
          />
        )}
      </motion.div>

      {/* OUTPUT */}
      <motion.div
        initial={{ scale: 0 }}
        animate={{ scale: 1 }}
        transition={{ duration: 0.5, delay: 1 }}
        className="relative"
      >
        <div className={`glass-card p-6 rounded-2xl ${stage === 'output' ? 'neon-glow-green' : ''}`}>
          <div className="flex flex-col items-center gap-3">
            <TrendingUp className="w-8 h-8 text-[#00ff88]" />
            <span className="text-white/80 text-sm">Prediction</span>
          </div>
        </div>
        {stage === 'output' && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            className="absolute -top-1 -right-1 w-3 h-3 bg-[#00ff88] rounded-full"
          >
            <div className="absolute inset-0 bg-[#00ff88] rounded-full animate-ping" />
          </motion.div>
        )}
      </motion.div>
    </div>
  );
}
