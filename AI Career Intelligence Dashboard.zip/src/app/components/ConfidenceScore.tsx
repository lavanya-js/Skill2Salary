import { motion } from "motion/react";
import { Brain, TrendingUp, Award, Target } from "lucide-react";

interface ConfidenceScoreProps {
  score: number;
  careerData: any;
}

export function ConfidenceScore({ score, careerData }: ConfidenceScoreProps) {
  const radius = 80;
  const circumference = 2 * Math.PI * radius;
  const strokeDashoffset = circumference - (score / 100) * circumference;

  const getScoreColor = (score: number) => {
    if (score >= 80) return '#00ff88';
    if (score >= 60) return '#00d4ff';
    return '#b537ff';
  };

  const getScoreMessage = (score: number) => {
    if (score >= 90) return 'Excellent Match';
    if (score >= 80) return 'Strong Match';
    if (score >= 70) return 'Good Match';
    return 'Growing Match';
  };

  return (
    <div className="glass-card p-8 rounded-3xl">
      <div className="flex items-center gap-3 mb-8">
        <Award className="w-8 h-8 text-[#00ff88]" />
        <div>
          <h2 className="text-3xl font-bold text-white">Career Confidence Score</h2>
          <p className="text-white/60">How well your profile matches industry demand</p>
        </div>
      </div>

      <div className="grid lg:grid-cols-2 gap-8 items-center">
        {/* Circular Progress */}
        <div className="flex justify-center">
          <div className="relative">
            {/* Background circle */}
            <svg className="w-64 h-64 transform -rotate-90">
              <circle
                cx="128"
                cy="128"
                r={radius}
                stroke="rgba(255,255,255,0.1)"
                strokeWidth="12"
                fill="none"
              />
              {/* Progress circle */}
              <motion.circle
                cx="128"
                cy="128"
                r={radius}
                stroke={getScoreColor(score)}
                strokeWidth="12"
                fill="none"
                strokeLinecap="round"
                strokeDasharray={circumference}
                initial={{ strokeDashoffset: circumference }}
                animate={{ strokeDashoffset }}
                transition={{ duration: 2, ease: "easeOut" }}
                style={{ filter: `drop-shadow(0 0 10px ${getScoreColor(score)})` }}
              />
            </svg>

            {/* Center content */}
            <div className="absolute inset-0 flex flex-col items-center justify-center">
              <Brain className="w-12 h-12 text-[#00d4ff] mb-2 pulse-glow" />
              <motion.div
                initial={{ scale: 0 }}
                animate={{ scale: 1 }}
                transition={{ delay: 0.5, type: "spring" }}
              >
                <div className="text-5xl font-bold text-white mb-1">{score}%</div>
                <div className="text-white/60 text-sm">{getScoreMessage(score)}</div>
              </motion.div>
            </div>
          </div>
        </div>

        {/* Breakdown */}
        <div className="space-y-4">
          <motion.div
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: 0.6 }}
            className="p-4 bg-white/5 rounded-xl border border-white/10"
          >
            <div className="flex items-center gap-3 mb-2">
              <Target className="w-5 h-5 text-[#00d4ff]" />
              <span className="text-white font-semibold">Role Alignment</span>
            </div>
            <div className="flex items-center gap-3">
              <div className="flex-1 h-2 bg-white/10 rounded-full overflow-hidden">
                <motion.div
                  initial={{ width: 0 }}
                  animate={{ width: '92%' }}
                  transition={{ delay: 0.8, duration: 1 }}
                  className="h-full bg-[#00d4ff]"
                />
              </div>
              <span className="text-[#00d4ff] font-semibold text-sm">92%</span>
            </div>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: 0.8 }}
            className="p-4 bg-white/5 rounded-xl border border-white/10"
          >
            <div className="flex items-center gap-3 mb-2">
              <Brain className="w-5 h-5 text-[#b537ff]" />
              <span className="text-white font-semibold">Skill Coverage</span>
            </div>
            <div className="flex items-center gap-3">
              <div className="flex-1 h-2 bg-white/10 rounded-full overflow-hidden">
                <motion.div
                  initial={{ width: 0 }}
                  animate={{ width: `${Math.min(65 + careerData.skills.length * 3, 95)}%` }}
                  transition={{ delay: 1, duration: 1 }}
                  className="h-full bg-[#b537ff]"
                />
              </div>
              <span className="text-[#b537ff] font-semibold text-sm">
                {Math.min(65 + careerData.skills.length * 3, 95)}%
              </span>
            </div>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: 1 }}
            className="p-4 bg-white/5 rounded-xl border border-white/10"
          >
            <div className="flex items-center gap-3 mb-2">
              <TrendingUp className="w-5 h-5 text-[#00ff88]" />
              <span className="text-white font-semibold">Market Demand</span>
            </div>
            <div className="flex items-center gap-3">
              <div className="flex-1 h-2 bg-white/10 rounded-full overflow-hidden">
                <motion.div
                  initial={{ width: 0 }}
                  animate={{ width: '88%' }}
                  transition={{ delay: 1.2, duration: 1 }}
                  className="h-full bg-[#00ff88]"
                />
              </div>
              <span className="text-[#00ff88] font-semibold text-sm">88%</span>
            </div>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 1.4 }}
            className="mt-6 p-4 bg-gradient-to-r from-[#00d4ff]/10 to-[#00ff88]/10 rounded-xl border border-[#00d4ff]/30"
          >
            <p className="text-white/90 text-sm">
              <span className="text-[#00ff88]">✓</span> Your profile matches{' '}
              <span className="text-white font-semibold">{score}%</span> of current industry demand for{' '}
              <span className="text-[#00d4ff] font-semibold">{careerData.role}</span>
            </p>
          </motion.div>
        </div>
      </div>
    </div>
  );
}
