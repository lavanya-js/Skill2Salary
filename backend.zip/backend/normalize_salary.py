import pandas as pd
import os

# ===============================
# Project Paths
# ===============================

BASE_DIR = os.path.dirname(os.path.abspath(__file__))

INPUT_FILE = os.path.join(
    BASE_DIR,
    "skill2salary_300_rows_india_remote.csv"
)

OUTPUT_FILE = os.path.join(
    BASE_DIR,
    "skill2salary_300_rows_realistic.csv"
)

# ===============================
# Salary Baselines (INR / Year)
# ===============================

ROLE_BASE = {
    "Software Engineer": 450000,
    "Backend Developer": 500000,
    "Frontend Developer": 450000,
    "Full Stack Developer": 550000,

    "Data Scientist": 600000,
    "Data Engineer": 550000,
    "Data Analyst": 400000,

    "Cloud Engineer": 600000,
    "DevOps Engineer": 550000,
}

LOCATION_FACTOR = {
    "Bangalore": 1.25,
    "Hyderabad": 1.15,
    "Chennai": 1.05,
    "Pune": 1.10,
    "Mumbai": 1.20,
    "Delhi NCR": 1.20,
    "Remote (India)": 1.00,
}

# ===============================
# Experience Multiplier
# ===============================

def get_experience_factor(exp):
    if exp <= 1:
        return 0.8
    elif exp <= 3:
        return 1.0
    elif exp <= 6:
        return 1.3
    elif exp <= 10:
        return 1.7
    elif exp <= 14:
        return 2.2
    else:
        return 2.6


# ===============================
# Salary Normalization Logic
# ===============================

def normalize_salary(row):

    role = row["jobTitle"]
    location = row["location"]
    experience = row["experience"]

    base = ROLE_BASE.get(role, 450000)
    loc_factor = LOCATION_FACTOR.get(location, 1.0)
    exp_factor = get_experience_factor(experience)

    final_salary = base * loc_factor * exp_factor

    return int(final_salary)


# ===============================
# Main Program
# ===============================

def main():

    print("📂 Looking for file at:")
    print(INPUT_FILE)

    if not os.path.exists(INPUT_FILE):
        print("❌ ERROR: CSV file not found!")
        print("Make sure it is inside backend folder.")
        return

    print("✅ File found!")
    print("📥 Loading data...")

    df = pd.read_csv(INPUT_FILE)

    print("Rows:", len(df))

    print("⚙️ Normalizing salaries...")

    df["salary"] = df.apply(normalize_salary, axis=1)

    print("💾 Saving file...")

    df.to_csv(OUTPUT_FILE, index=False)

    print("✅ DONE!")
    print("📁 Output file:", OUTPUT_FILE)
    print("Rows:", len(df))


# ===============================
# Run
# ===============================

if __name__ == "__main__":
    main()