package com.skill2salary.backend.service;

import com.skill2salary.backend.dto.*;
import com.skill2salary.backend.model.SalaryRecord;
import com.skill2salary.backend.util.CSVLoader;
import com.skill2salary.backend.util.SkillExtractor;
import org.springframework.stereotype.Service;

import java.util.*;
import java.util.stream.Collectors;

@Service
public class PredictionService {

    private final CSVLoader csvLoader;
    private final SkillExtractor skillExtractor;

    public PredictionService(CSVLoader csvLoader,
                             SkillExtractor skillExtractor) {
        this.csvLoader = csvLoader;
        this.skillExtractor = skillExtractor;
    }

    public PredictResponse predict(PredictRequest req) {

        List<SalaryRecord> data = csvLoader.getRecords();

        // Filter dataset by role and location
        List<SalaryRecord> filtered = data.stream()
                .filter(r -> r.getRole().equalsIgnoreCase(req.getRole()))
                .filter(r -> r.getLocation().equalsIgnoreCase(req.getLocation()))
                .collect(Collectors.toList());

        if (filtered.isEmpty()) {
            filtered = data;
        }

        // Base salary from dataset
        double baseSalary = filtered.stream()
                .mapToDouble(SalaryRecord::getSalary)
                .average()
                .orElse(600000);

        // Experience factor
        double expFactor = 1 + (req.getExperience() * 0.08);

        // Collect market skills
        Set<String> marketSkills = filtered.stream()
                .flatMap(r -> r.getSkills().stream())
                .map(String::toLowerCase)
                .collect(Collectors.toSet());

        int matchCount = 0;

        for (String s : req.getSkills()) {
            if (marketSkills.contains(s.toLowerCase().trim())) {
                matchCount++;
            }
        }

        // Skill factor
        double skillFactor = 1 + (matchCount * 0.03);

        // Final salary prediction
        double predictedSalary = baseSalary * expFactor * skillFactor;

        // Salary range
        SalaryRange range = new SalaryRange(
                predictedSalary * 0.85,
                predictedSalary * 1.15
        );

        // ===== Skill Recommendation Algorithm =====

        Map<String, Integer> skillFrequency = new HashMap<>();

        for (SalaryRecord r : filtered) {
            for (String skill : r.getSkills()) {

                String normalized = skill.toLowerCase();

                skillFrequency.put(
                        normalized,
                        skillFrequency.getOrDefault(normalized, 0) + 1
                );
            }
        }

        // Remove skills already known by user
        for (String userSkill : req.getSkills()) {
            skillFrequency.remove(userSkill.toLowerCase());
        }

        // Sort by demand
        List<String> recommended = skillFrequency.entrySet()
                .stream()
                .sorted((a, b) -> b.getValue() - a.getValue())
                .limit(5)
                .map(Map.Entry::getKey)
                .collect(Collectors.toList());

        // Trending skills
        List<String> trending = List.of(
                "GenAI",
                "Kubernetes",
                "Microservices",
                "Cloud",
                "System Design",
                "LLMs"
        );

        // Response
        PredictResponse res = new PredictResponse();
        res.setPredictedSalary(predictedSalary);
        res.setSalaryRange(range);
        res.setRecommendedSkills(recommended);
        res.setTrendingSkills(trending);
        res.setConfidenceScore(90.0);

        return res;
    }
}