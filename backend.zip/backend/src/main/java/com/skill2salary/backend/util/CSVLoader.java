package com.skill2salary.backend.util;

import com.opencsv.CSVReader;
import com.skill2salary.backend.model.SalaryRecord;
import jakarta.annotation.PostConstruct;
import org.springframework.stereotype.Component;

import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.*;

@Component
public class CSVLoader {

    private final List<SalaryRecord> records = new ArrayList<>();

    @PostConstruct
    public void loadCSV() {

        try {

            InputStream is = getClass()
                    .getClassLoader()
                    .getResourceAsStream("data/data.csv");

            if (is == null) {
                throw new RuntimeException("data/data.csv NOT FOUND in resources!");
            }

            CSVReader reader = new CSVReader(new InputStreamReader(is));

            // Skip header
            reader.readNext();

            String[] line;

            while ((line = reader.readNext()) != null) {

                if (line.length < 7) continue;

                String role = line[2].trim();
                String location = line[3].trim();

                int experience =
                        Integer.parseInt(line[4].trim());

                List<String> skills =
                        parseSkills(line[5]);

                long salary =
                        Long.parseLong(line[6].trim());

                records.add(new SalaryRecord(
                        role,
                        location,
                        salary,
                        experience,
                        skills
                ));
            }

            reader.close();

            System.out.println("CSV Loaded: " + records.size() + " records");

        } catch (Exception e) {

            System.err.println("Failed to load CSV");
            e.printStackTrace();
        }
    }

    private List<String> parseSkills(String text) {

        if (text == null || text.isEmpty())
            return Collections.emptyList();

        String[] parts = text.split("[,\\s]+");

        Set<String> set = new HashSet<>();

        for (String p : parts) {

            String s = p.trim().toLowerCase();

            if (s.length() > 2)
                set.add(s);
        }

        return new ArrayList<>(set);
    }

    public List<SalaryRecord> getRecords() {
        return records;
    }
}