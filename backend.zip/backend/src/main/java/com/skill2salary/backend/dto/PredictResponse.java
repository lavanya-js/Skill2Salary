package com.skill2salary.backend.dto;

import java.util.List;

public class PredictResponse {

    private double predictedSalary;
    private SalaryRange salaryRange;
    private List<String> recommendedSkills;
    private List<String> trendingSkills;
    private double confidenceScore;

    public double getPredictedSalary() {
        return predictedSalary;
    }

    public void setPredictedSalary(double predictedSalary) {
        this.predictedSalary = predictedSalary;
    }

    public SalaryRange getSalaryRange() {
        return salaryRange;
    }

    public void setSalaryRange(SalaryRange salaryRange) {
        this.salaryRange = salaryRange;
    }

    public List<String> getRecommendedSkills() {
        return recommendedSkills;
    }

    public void setRecommendedSkills(List<String> recommendedSkills) {
        this.recommendedSkills = recommendedSkills;
    }

    public List<String> getTrendingSkills() {
        return trendingSkills;
    }

    public void setTrendingSkills(List<String> trendingSkills) {
        this.trendingSkills = trendingSkills;
    }

    public double getConfidenceScore() {
        return confidenceScore;
    }

    public void setConfidenceScore(double confidenceScore) {
        this.confidenceScore = confidenceScore;
    }
}