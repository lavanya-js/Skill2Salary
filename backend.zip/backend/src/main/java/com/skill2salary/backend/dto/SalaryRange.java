package com.skill2salary.backend.dto;

public class SalaryRange {

    private double min;
    private double max;

    public SalaryRange(double min, double max) {
        this.min = min;
        this.max = max;
    }

    public double getMin() {
        return min;
    }

    public double getMax() {
        return max;
    }
}