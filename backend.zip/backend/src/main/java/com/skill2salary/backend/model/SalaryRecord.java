package com.skill2salary.backend.model;

import java.util.List;

public class SalaryRecord {

    private String role;
    private String location;
    private long salary;
    private int experience;
    private List<String> skills;

    public SalaryRecord(String role,
                        String location,
                        long salary,
                        int experience,
                        List<String> skills) {

        this.role = role;
        this.location = location;
        this.salary = salary;
        this.experience = experience;
        this.skills = skills;
    }

    public String getRole() {
        return role;
    }

    public String getLocation() {
        return location;
    }

    public long getSalary() {     return salary;
    }

    public int getExperience() {
        return experience;
    }

    public List<String> getSkills() {
        return skills;
    }
}