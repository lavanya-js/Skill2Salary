package com.skill2salary.backend.util;

import com.skill2salary.backend.model.SalaryRecord;
import org.springframework.stereotype.Component;

import java.util.*;
import java.util.stream.Collectors;

@Component
public class SkillExtractor {

    private final CSVLoader csvLoader;

    public SkillExtractor(CSVLoader csvLoader) {
        this.csvLoader = csvLoader;
    }

    public List<String> extractMissingSkills(
            String role,
            List<String> userSkills) {

        List<SalaryRecord> data = csvLoader.getRecords();

        List<String> marketSkills = data.stream()
                .filter(r -> r.getRole().equalsIgnoreCase(role))
                .flatMap(r -> r.getSkills().stream())
                .collect(Collectors.toList());

        Map<String, Integer> freq = new HashMap<>();
        for (String s : marketSkills) {
            freq.put(s.toLowerCase(), freq.getOrDefault(s.toLowerCase(), 0) + 1);
        }

        Set<String> userSet = userSkills.stream()
                .map(String::toLowerCase)
                .collect(Collectors.toSet());

        return freq.entrySet().stream()
                .filter(e -> !userSet.contains(e.getKey()))
                .sorted((a, b) -> b.getValue() - a.getValue())
                .limit(6)
                .map(Map.Entry::getKey)
                .collect(Collectors.toList());
    }
}