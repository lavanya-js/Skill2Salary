package com.skill2salary.backend.controller;

import com.skill2salary.backend.dto.PredictRequest;
import com.skill2salary.backend.dto.PredictResponse;
import com.skill2salary.backend.service.PredictionService;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api")
@CrossOrigin(origins = "*")
public class PredictController {

    private final PredictionService predictionService;

    public PredictController(PredictionService predictionService) {
        this.predictionService = predictionService;
    }

    @PostMapping("/predict")
    public PredictResponse predict(@RequestBody PredictRequest req) {
        return predictionService.predict(req);
    }
}