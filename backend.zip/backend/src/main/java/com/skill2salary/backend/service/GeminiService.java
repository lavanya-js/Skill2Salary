package com.skill2salary.backend.service;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import jakarta.annotation.PostConstruct;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import java.util.*;

@Service
public class GeminiService {

    @Value("${gemini.api.key}")
    private String apiKey;


    private static final String GEMINI_URL =
            "https://generativelanguage.googleapis.com/v1/models/gemini-1.5-flash:generateContent?key=";
    private final RestTemplate restTemplate = new RestTemplate();
    private final ObjectMapper mapper = new ObjectMapper();


    @PostConstruct
    public void checkKey() {
        System.out.println("Gemini key loaded: " + (apiKey != null && !apiKey.isEmpty()));
    }


    public List<String> getRecommendedSkills(
            String role,
            List<String> userSkills,
            String location) {

        return callGemini(
                """
                You are an expert tech career advisor.
                Role: %s
                Location: %s
                Current skills: %s
                Considering LOCAL JOB MARKET demand in %s:
                Suggest 6 MOST IMPORTANT skills to learn next.
                Do NOT repeat existing skills.
                Return ONLY comma separated skill names.
                """.formatted(role, location, String.join(", ", userSkills), location),
                List.of("System Design","Cloud","Docker","Kubernetes","CI/CD")
        );
    }

    public List<String> getTrendingSkills(
            String role,
            String location) {

        return callGemini(
                """
                You are a tech market analyst AI.

                Role: %s
                Location: %s

                Based on CURRENT industry growth in %s:
                List 6 BOOMING or high-growth skills for this role.
                Return ONLY comma separated skill names.
                """.formatted(role, location, location),
                List.of("GenAI","Kubernetes","MLOps","Cloud","LLMs","Platform Engineering")
        );
    }

    private List<String> callGemini(String prompt, List<String> fallback) {

        try {

            Map<String, Object> body = Map.of(
                    "contents", List.of(
                            Map.of(
                                    "parts", List.of(
                                            Map.of("text", prompt)
                                    )
                            )
                    )
            );

            String response = restTemplate.postForObject(
                    GEMINI_URL + apiKey,
                    body,
                    String.class
            );

            if (response == null || response.isEmpty()) {
                System.err.println("Gemini empty response");
                return fallback;
            }

            JsonNode root = mapper.readTree(response);

            String text = root
                    .at("/candidates/0/content/parts/0/text")
                    .asText("");

            if (text.isBlank()) {
                System.err.println("Gemini returned blank text");
                return fallback;
            }

            List<String> skills = Arrays.stream(text.split(","))
                    .map(String::trim)
                    .filter(s -> !s.isEmpty())
                    .toList();

            if (skills.isEmpty()) return fallback;

            return skills;

        } catch (Exception e) {
            System.err.println("GEMINI ERROR:");
            e.printStackTrace();
            return fallback;
        }
    }
}