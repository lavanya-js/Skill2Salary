package com.skill2salary.backend.dto;

import java.util.List;

public class SkillTrendResponse {

    private List<String> trendingSkills;
    private String source;

    public SkillTrendResponse(List<String> trendingSkills) {
        this.trendingSkills = trendingSkills;
        this.source = "AI (Gemini)";
    }

    public List<String> getTrendingSkills() {
        return trendingSkills;
    }

    public String getSource() {
        return source;
    }
}