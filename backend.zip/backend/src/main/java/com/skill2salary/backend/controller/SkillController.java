package com.skill2salary.backend.controller;

import com.skill2salary.backend.dto.*;
import com.skill2salary.backend.service.GeminiService;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/skills")
@CrossOrigin
public class SkillController {

    private final GeminiService geminiService;

    public SkillController(GeminiService geminiService) {
        this.geminiService = geminiService;
    }

    @PostMapping("/trending")
    public SkillTrendResponse getTrendingSkills(
            @RequestBody SkillTrendRequest request) {

        var skills = geminiService.getRecommendedSkills(
                request.getRole(),
                request.getCurrentSkills(),
                request.getLocation()
        );

        return new SkillTrendResponse(skills);
    }
}